// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCPW2gpkg2t9xP0FxXq7CkAYO7K7C-VCco",
    authDomain: "betinho-67b5e.firebaseapp.com",
    projectId: "betinho-67b5e",
    storageBucket: "betinho-67b5e.firebasestorage.app",
    messagingSenderId: "563375935508",
    appId: "1:563375935508:web:54a1bd108a630938859701",
    measurementId: "G-7ZGPZ95K7Z"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
