import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'login',
    loadComponent: () =>
      import('./pages/login/login.page').then(m => m.LoginPage),
  },
  {
    path: 'home',
    loadComponent: () =>
      import('./pages/home/home.page').then(m => m.HomePage),
  },
  {
    path: 'agendar-consulta',
    loadComponent: () =>
      import('./pages/agendar-consulta/agendar-consulta.page').then(m => m.AgendarConsultaPage),
  },
  {
    path: '**',
    redirectTo: 'login',
  },

   
 
  
  {
    path: 'agendar-consulta',
    loadComponent: () => import('./pages/agendar-consulta/agendar-consulta.page').then( m => m.AgendarConsultaPage)
  },
  {
    path: 'agendar-consulta',
    loadComponent: () => import('./pages/agendar-consulta/agendar-consulta.page').then( m => m.AgendarConsultaPage)
  },
];


