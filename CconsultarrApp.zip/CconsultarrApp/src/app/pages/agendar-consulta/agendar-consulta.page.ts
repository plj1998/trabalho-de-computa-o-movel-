import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  FormsModule
} from '@angular/forms';
import { IonicModule, ToastController } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-agendar-consulta',
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './agendar-consulta.page.html',
  styleUrls: ['./agendar-consulta.page.scss']
})
export class AgendarConsultaPage {
  agendamentoForm!: FormGroup;

  especialidades: string[] = [
    'Cardiologia',
    'Dermatologia',
    'Pediatria',
    'Neurologia',
    'Ortopedia',
    'Ginecologia'
  ];

  horariosDisponiveis: string[] = [
    '08:00', '09:30', '11:00',
    '13:30', '15:00', '16:30'
  ];

  constructor(
    private fb: FormBuilder,
    private toastController: ToastController,
    private router: Router
  ) {}

  ngOnInit() {
    this.agendamentoForm = this.fb.group({
      nome: ['', Validators.required],
      sintomas: ['', Validators.required],
      especialidade: ['', Validators.required],
      horario: ['', Validators.required]
    });
  }

  selecionarEspecialidade(especialidade: string) {
    this.agendamentoForm.patchValue({ especialidade });
  }

  selecionarHorario(horario: string) {
    this.agendamentoForm.patchValue({ horario });
  }

  async agendar() {
    if (this.agendamentoForm.invalid) {
      const toast = await this.toastController.create({
        message: 'Preencha todos os campos obrigatórios.',
        duration: 3000,
        color: 'danger'
      });
      await toast.present();
      return;
    }

    console.log('Agendamento:', this.agendamentoForm.value);

    const toast = await this.toastController.create({
      message: '✅ Consulta agendada com sucesso!',
      duration: 3000,
      color: 'success'
    });

    await toast.present();
    this.agendamentoForm.reset();
  }

  voltar() {
    this.router.navigate(['/home']);
  }
}
