import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IonicModule, ToastController } from '@ionic/angular';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { Auth, signInWithEmailAndPassword } from '@angular/fire/auth';
import { initializeApp } from 'firebase/app';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  imports: [IonicModule, CommonModule, ReactiveFormsModule]
})
export class LoginPage {
  loginForm: FormGroup;
  loading = false;

  constructor(
    private fb: FormBuilder,
    private auth: Auth,
    private router: Router,
    private toastController: ToastController
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      senha: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  async login() {
    if (this.loginForm.invalid) {
      this.showToast('Por favor, preencha todos os campos corretamente.', 'danger');
      return;
    }

    const { email, senha } = this.loginForm.value;
    this.loading = true;

    try {
      await signInWithEmailAndPassword(this.auth, email, senha);
      this.showToast('Login realizado com sucesso!', 'success');
      this.router.navigate(['/home']);
    } catch (error: any) {
      let mensagem = 'Erro ao fazer login.';
      switch (error.code) {
        case 'auth/user-not-found':
          mensagem = 'Usuário não encontrado.';
          break;
        case 'auth/wrong-password':
          mensagem = 'Senha incorreta.';
          break;
        case 'auth/invalid-email':
          mensagem = 'Email inválido.';
          break;
        default:
          mensagem = 'Erro desconhecido. Tente novamente.';
      }
      this.showToast(mensagem, 'danger');
    } finally {
      this.loading = false;
    }
  }

  async showToast(message: string, color: 'danger' | 'success' | 'warning') {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      color,
    });
    await toast.present();
  }
}
